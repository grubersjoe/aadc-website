//
// Created by fabian on 18.09.17.
//

#ifndef HTWK_ZEBRASTATE_H
#define HTWK_ZEBRASTATE_H

enum class ZebraState {
    ONROAD = 0,
    NEARINGZEBRA = 1,
    STOPNOW = 2
};

#endif //HTWK_ZEBRASTATE_H
