//
// Created by fabian on 29.09.17.
//

#ifndef AADC_USER_MANUEVERENUM_H
#define AADC_USER_MANUEVERENUM_H

enum class ManeuverEnum {
    STRAIGHT,
    LEFT,
    RIGHT,
    CROSS_PARKING,
    PULLOUT_LEFT,
    PULLOUT_RIGHT
};

#endif //AADC_USER_MANUEVERENUM_H
