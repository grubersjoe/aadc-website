#!/bin/sh
./generate_python.sh
./generate_cpp.sh
