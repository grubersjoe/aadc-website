Open two instances of your ADTF (ADTF1 and ADTF2).

ADTF1: load the Project demo_udpSender.
ADTF2: load the Project demo_udpReceiver.
	
INIT the demo_udpReceiver project in ADTF2 before you INIT the demo_udpSender project in ADTF1!