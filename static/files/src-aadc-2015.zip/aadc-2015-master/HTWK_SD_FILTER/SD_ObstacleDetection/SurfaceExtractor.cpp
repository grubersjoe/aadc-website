/**
 * Copyright (c) 2014-2015, HTWK SmartDriving
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * AUTHORS: Silvio Feig, Denny Hecht, Andreas Kluge, Lars Kollmann, Eike Florian Petersen, Artem Pokas
 *
 */

#include "SurfaceExtractor.h"
#include "SurfaceDescription.h"

#include <stack>
#include <iostream>
#include <iomanip>

#include <opencv/cv.h>
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>

SurfaceExtractor::SurfaceExtractor()
{
	numberOfSurfaces = 0;
}

std::vector<SurfaceDescription>& SurfaceExtractor::process(const cv::Mat& image)
{
	allocateImageIfNecessary(sourceImage, image.size(), sourceImage.type());
	clearImage(sourceImage);
	image.copyTo(sourceImage);

	allocateImageIfNecessary(labeledImage, sourceImage.size(), sourceImage.type());
	clearImage(labeledImage);

	surfaceDescriptions.clear();

	numberOfSurfaces = 0;
	int surfaceId = 1;
	for (int r=0; r<sourceImage.rows; ++r)
	{
		for (int c=0;c<sourceImage.cols; ++c)
		{
			cv::Point currentPoint(c,r);

			if (!isLabeled(sourceImage, currentPoint)) { continue; }
			if (isLabeled(labeledImage, currentPoint)) { continue; }
			
			// std::cout << "encountered unlabeleld pixel at - row: " << r << ", col: " << c << std::endl;
			SurfaceDescription surfaceDescription(surfaceId);
			floodFill(currentPoint, sourceImage, labeledImage, surfaceDescription);
			surfaceDescriptions.push_back(surfaceDescription);

			surfaceId+=1;
		}
	}
	numberOfSurfaces = surfaceId;

	return surfaceDescriptions;
}

void SurfaceExtractor::allocateImageIfNecessary(cv::Mat& image, cv::Size size, int type)
{
	image.create(size, type);
}

void SurfaceExtractor::clearImage(cv::Mat& image)
{
	image = cv::Mat::zeros(image.rows, image.cols, image.type());
}

bool SurfaceExtractor::isLabeled(const cv::Mat& image, const cv::Point& p)
{
	if (image.at<ushort>(p.y, p.x) == 0)
	{
		return false;
	}
	return true;
}

void SurfaceExtractor::floodFill(const cv::Point& start,
								const cv::Mat& sourceImage, cv::Mat& labeledImage,
								SurfaceDescription& surfaceDescription)
{
	unsigned int surfaceId = surfaceDescription.id;
	int pixelCount = 0;

	std::stack<cv::Point> stack;
	stack.push(start);

	while (!stack.empty())
	{
		cv::Point currentPoint = stack.top(); stack.pop();
		
		surfaceDescription.add(currentPoint, sourceImage.at<ushort>(currentPoint.y, currentPoint.x));

		labeledImage.at<ushort>(currentPoint.y, currentPoint.x) = surfaceId;

		cv::Point topLeft(currentPoint.x-1, currentPoint.y-1);
		checkLabelAndPush(topLeft, sourceImage, labeledImage, stack, surfaceId);

		cv::Point top(currentPoint.x, currentPoint.y-1);
		checkLabelAndPush(top, sourceImage, labeledImage, stack, surfaceId);

		cv::Point topRight(currentPoint.x+1, currentPoint.y-1);
		checkLabelAndPush(topRight, sourceImage, labeledImage, stack, surfaceId);

		cv::Point right(currentPoint.x+1, currentPoint.y);
		checkLabelAndPush(right, sourceImage, labeledImage, stack, surfaceId);

		cv::Point left(currentPoint.x-1, currentPoint.y);
		checkLabelAndPush(left, sourceImage, labeledImage, stack, surfaceId);

		cv::Point bottomLeft(currentPoint.x-1, currentPoint.y+1);
		checkLabelAndPush(bottomLeft, sourceImage, labeledImage, stack, surfaceId);

		cv::Point bottom(currentPoint.x, currentPoint.y+1);
		checkLabelAndPush(bottom, sourceImage, labeledImage, stack, surfaceId);

		cv::Point bottomRight(currentPoint.x+1, currentPoint.y+1);
		checkLabelAndPush(bottomRight, sourceImage, labeledImage, stack, surfaceId);

		pixelCount += 1;
	}
	surfaceDescription.size = pixelCount;
}

void SurfaceExtractor::checkLabelAndPush(const cv::Point& point,
									     const cv::Mat& sourceImage, cv::Mat& labeledImage,
										 std::stack<cv::Point>& stack,
										 int surfaceId)
{
	if (isLabeled(sourceImage, point)
			&& !isLabeled(labeledImage, point)
			&& isInImage(sourceImage, point))
	{
		stack.push(point);
		labeledImage.at<ushort>(point.y, point.x) = surfaceId;
	}
}

bool SurfaceExtractor::isInImage(const cv::Mat& image, const cv::Point& p)
{
	return ((p.y < image.rows && p.y >= 0) && (p.x < image.cols && p.x >= 0));
}

/*
void SurfaceExtractor::getSurfaceDescriptionById(int surfaceId, SurfaceDescription& surfaceDescription)
{
	int pixelCount = 0;

	for (int r=0; r<labeledImage.rows; r++)
	{
		for (int c=0; c<labeledImage.cols; c++)
		{
			if (labeledImage.at<ushort>(r,c) == surfaceId)
			{
				surfaceDescription.add(cv::Point(c, r), sourceImage.at<ushort>(c, r));
				pixelCount++;
			}
		}
	}

	surfaceDescription.id = surfaceId;
	surfaceDescription.size = pixelCount;
}

void SurfaceExtractor::getLargestSurface(SurfaceDescription& descriptionLargestSurface)
{
	unsigned short idLargestSurface = 0;
	unsigned int largestSurfaceSize = 0;

	for (auto idAndSize : surfaceDescriptions)
	{
		if (idAndSize.size > largestSurfaceSize)
		{
			idLargestSurface = idAndSize.id;	
			largestSurfaceSize = idAndSize.size;
		}
	}

	if (!surfaceDescriptions.empty())
	{
		getSurfaceDescriptionById(idLargestSurface, descriptionLargestSurface);
	}
}
*/

unsigned int SurfaceExtractor::getNumberOfSurfaces()
{
	return numberOfSurfaces;
}

cv::Mat& SurfaceExtractor::getLabeledImage()
{
	return labeledImage;
}
