|	|	|
|	|	|
|		|
|	|	|
|	|	|
|		|
|	|	|
|	|	|
|		|
|	|	|
|       |   _	|
	   | | <- Auto, steht mit dem vordersten Sensor direkt an der untersten Kante
 	    -	  einer mittleren Fahrspur, und 5cm Abstand zum rechten Fahrbahnrand