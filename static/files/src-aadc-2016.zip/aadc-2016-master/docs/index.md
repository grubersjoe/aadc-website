# HTWK Smart-Driving Dokumentation


## Allgemeines
Das ist die HTWK Smart-Driving Dokumentation

## Filter
[Emergency Braking](filter/htwk_emergency_braking.md)
[Grayscale](filter/htwk_grayscale.md)
[Noise Remover](filter/htwk_noise_remover.md)
[Region of Interest](filter/htwk_region_of_interest.md)
