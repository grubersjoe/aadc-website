// Driving
#define DM_LANE_DRIVER 1
#define DM_COLL_PREV 2
#define DM_PASSING 3
#define DM_TURN 4


// Parking
#define DM_CROSS_PARKING 10
#define DM_PARALLEL_PARKING 11
#define DM_PULL_OUT 12

// Misc
#define DM_IDLE 100
//#define DM_MAGIC 50

