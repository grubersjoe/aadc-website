/**
 * @author gjenschmischek
 */

#ifndef _T_LANE
#define _T_LANE

#include "stdafx.h"
#include "tLine.h"
#include "tPoint.h"

typedef struct
{
    tLine tLeftLine;
    tLine tRightLine;
} tLane;

#endif
