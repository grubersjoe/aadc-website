/**
 * @author gjenschmischek
 */
#ifndef _T_LINE_STATUS
#define _T_LINE_STATUS

typedef enum
{
    tINVISIBLE = 111,
    tVISIBLE = 112,
    tCROSSING = 113
} tLineStatus;

#endif
