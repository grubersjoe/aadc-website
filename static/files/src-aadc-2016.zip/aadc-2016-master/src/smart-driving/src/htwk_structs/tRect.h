/**
 * @author pbachmann
 */

#ifndef _T_RECT
#define _T_RECT

#include "stdafx.h"

typedef struct
{
    tInt16 tX;
    tInt16 tY;
    tInt16 tWidth;
    tInt16 tHeight;
} tRect;

#endif
