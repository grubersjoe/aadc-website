//
// Created by pbachmann on 2/16/16.
//

#ifndef HTWK_2016_DIRECTION_H
#define HTWK_2016_DIRECTION_H

struct Direction
{
    enum DirectionEnum
    {
        STRAIGHT,
        LEFT,
        RIGHT
    };
};

#endif //HTWK_2016_DIRECTION_H
