/**
 * @author gjenschmischek
 */
#ifndef _T_POINT
#define _T_POINT

#include "stdafx.h"

typedef struct
{
    tFloat32 tX;
    tFloat32 tY;
} tPoint;

#endif
