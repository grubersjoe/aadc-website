
#ifndef __STD_INCLUDES_HEADER
#define __STD_INCLUDES_HEADER

#include <adtf_platform_inc.h>
#include <adtf_plugin_sdk.h>
using namespace adtf;

#include <adtf_graphics.h>
using namespace adtf_graphics;




#endif // __STD_INCLUDES_HEADER
