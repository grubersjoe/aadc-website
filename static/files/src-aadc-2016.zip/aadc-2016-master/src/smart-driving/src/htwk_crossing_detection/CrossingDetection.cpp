//
// Created by pbachmann on 2/17/16.
//

#include "CrossingDetection.h"


CrossingDetection::CrossingDetection()
{ }

CrossingDetection::~CrossingDetection()
{ }

void CrossingDetection::CheckLeftLane()
{

}
