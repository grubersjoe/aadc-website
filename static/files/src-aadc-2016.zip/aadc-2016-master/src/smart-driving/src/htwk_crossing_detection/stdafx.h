#ifndef __STD_INCLUDES_HEADER
#define __STD_INCLUDES_HEADER

#include <adtf_platform_inc.h>
#include <adtf_plugin_sdk.h>

using namespaceadtf;
               using namespace adtf_util;

#endif // __STD_INCLUDES_HEADER
