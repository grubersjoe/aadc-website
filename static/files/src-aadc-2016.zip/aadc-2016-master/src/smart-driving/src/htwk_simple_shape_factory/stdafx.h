/**
 *
 * ADTF Demo Source.
 *
 * @file
 * Copyright &copy; Audi Electronics Venture GmbH. All rights reserved
 *
 * $Author: belkera $
 * $Date: 2011-07-01 08:26:22 +0200 (Fri, 01 Jul 2011) $
 * $Revision: 7968 $
 *
 * @remarks
 *
 */
#ifndef __STD_INCLUDES_HEADER
#define __STD_INCLUDES_HEADER

#include <adtf_plugin_sdk.h>
using namespace adtf;

#include </opt/adtf/addons/adtf-display-toolbox/include/shapes_input.h>

#endif // __STD_INCLUDES_HEADER
