/************************************************************************/
/* SWA filter.                                                          */
/*                                                                      */
/* Standard or project specific includes.                               */
/*                                                                      */
/* @copyright       Copyright (c) 2008 Audi AG. All rights reserved.    */
/*                                                                      */
/* @file            $RCSfile: stdafx.cpp $                              */
/* $Author: FSCHRUW $                                                   */
/* $Date: 2012-09-10 13:54:59 +0200 (Mon, 10 Sep 2012) $                 */
/* $Revision: 33919 $                                                   */
/* @remarks                                                             */
/* @history         22.06.2007  K. Zawicki:    Initial version          */
/************************************************************************/

#include "stdafx.h"
