//
// Created by pbachmann on 2/11/16.
//

class tWorldData
{
    public:
        void *data;
        cReadWriteMutex *lock;
};
