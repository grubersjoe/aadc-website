//
// Created by pbachmann on 1/6/16.
//

#ifndef HTWK_2016_LANELINEMODE_H
#define HTWK_2016_LANELINEMODE_H

enum LaneLineMode
{
    INIT,
    FULL,
    BROKEN,
    CROSSING,
    VANISHED,
    LOST
};

#endif //HTWK_2016_LANELINEMODE_H
